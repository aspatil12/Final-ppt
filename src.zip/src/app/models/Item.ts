import {ProductInfo} from "./productInfo";

export class Item {
    quantity: number;
    productInfo: ProductInfo

}
